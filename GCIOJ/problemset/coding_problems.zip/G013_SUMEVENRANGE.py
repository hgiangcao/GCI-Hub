import random
random.seed(42)

def generate_int_num(min_val=0, max_val=1000):
    return random.randint(min_val, max_val)

def generate_int_arr(n_num=20, min_val=-1000, max_val=1000):
    return [random.randint(min_val, max_val) for _ in range(n_num)]



def correct_solution(start, end):
    return sum(x for x in range(start, end + 1) if x % 2 == 0)

def auto_grade():
    score = 0
    n_test = 100
    status = "Pending"
    
    try:
        for i in range(1, n_test + 1):
            # Generate random test cases
            start = generate_int_num(0, 50); end = generate_int_num(start, start + 50)

            try:
                # Create a copy so student code doesn't mess up original data
                pass

                # Run functions
                student_ans = solve(start, end)
                correct_ans = correct_solution(start, end)

                if student_ans == correct_ans:
                    score += 1
            except Exception as e:
                status = "Compile Error"
    except Exception as e:
        status = "Compile Error"

    print(f"Final Score: {score} / {n_test}")

    if (score == n_test):
        status = "Accepted"
    elif (status != "Compile Error"):
        status = "Wrong Answer"

    print("Status:", status)

if "solve" in globals():
    try:
        auto_grade()
    except Exception as e:
        print("Status:", "Compile Error")
else:
    print("Compilation Error: Function 'solve' is not defined.")
    print("Status:", "Compile Error")
